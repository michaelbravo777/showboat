# Three.js MP3 player

###Downloads https://github.com/michaelbravo777/showboat/tree/master/release-builds

Select your music folder to get started.

![](/../screenshots/Screenshot from 2017-02-09 22-30-17.png?raw=true)



![](/../screenshots/Screenshot from 2017-02-09 22-30-35.png?raw=true)

Navigate to a folder or select a song to play.

![](/../screenshots/Screenshot from 2017-02-09 22-31-06.png?raw=true)

Click on visuals.

![](/../screenshots/Screenshot from 2017-02-09 22-31-56.png?raw=true)

Right click to change colors.

![](/../screenshots/Screenshot from 2017-02-09 22-32-11.png?raw=true)
