# Three.js MP3 player

###Downloads https://github.com/michaelbravo777/showboat/tree/master/release-builds

Select your music folder to get started (Right click or control-click on Mac).

![](/../screenshots/Screenshot from 2017-02-12 01-33-34.png?raw=true)

Navigate to a folder or select a song to play.

![](/../screenshots/Screenshot from 2017-02-12 01-34-07.png?raw=true)

Click on visuals.

![](/../screenshots/Screenshot from 2017-02-12 01-34-19.png?raw=true)

Right click to change colors.

![](/../screenshots/Screenshot from 2017-02-12 01-34-31.png?raw=true)
